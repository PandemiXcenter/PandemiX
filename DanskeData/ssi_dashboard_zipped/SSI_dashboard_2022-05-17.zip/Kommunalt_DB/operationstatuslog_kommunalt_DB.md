# Driftslog

**English version below the Danish version**

Alle betydelige hændelser i driftsituationen, der har betydning for covid-19 tallene bliver dokumenteret i denne fil.

Formatet in filen er: 
## [Tidspunkt for hændelsen (fra hvornår det havde betydning for tallene)]
"[Hændelsens betydning for tallene]", [hændelsens periode], "[hændelsens note på hjemmeside og/eller dashboardet]"

### 2021-12-22T14:00:00 
"8000 prøvesvar fra Hovedstaden og Sjælland har fået 'inkonklusivt' prøvesvar", 2021-12-22T14:00:00/2021-12-22T13:59:59, "Bemærk: Onsdag 22. december 2021 Som følge af laboratoriefejl i TCD er 8000 prøvesvar fra Hovedstaden og Sjælland påvirket. Læs mere her: https://www.ssi.dk/aktuelt/nyheder/2021/har-mattet-melde-8000-prover-ud-med-svaret-inkonklusivt "

**slutning af dansk version**

**English version**

# Operation status log

This log contains all significant issues that affected the covid-19 numbers.

The format in the file is as follows: 
## [Date and time for the incident (from when it was affecting the number)]
"[How the incident affects the numbers]", [the timeframe of the incident], "[the incident note on the homepage and/or the dashboard]"


### 2021-12-22T14:00:00 
"8000 test from the 'Hovedstaden' and 'Sjælland' have recieved a 'inconclusive' test result.", 2021-12-22T14:00:00/2021-12-22T13:59:59, "Bemærk: Onsdag 22. december 2021 Som følge af laboratoriefejl i TCD er 8000 prøvesvar fra Hovedstaden og Sjælland påvirket. Læs mere her: https://www.ssi.dk/aktuelt/nyheder/2021/har-mattet-melde-8000-prover-ud-med-svaret-inkonklusivt "

**end of English version**
