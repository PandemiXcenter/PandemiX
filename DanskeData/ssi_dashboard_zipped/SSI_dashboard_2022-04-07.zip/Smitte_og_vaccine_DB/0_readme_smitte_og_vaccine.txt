﻿README - SMITTE OG VACCINE
------------------------------------------------------

Dette dokument beskriver indholdet af zip-filen, som indeholder data fra SSIs smitte- og vaccinedashboard.
Zippen opdateres mandage kl. 14. Filer med ugentlige tidsserier kan ændre sig tilbage i tiden, hvis nyere data foreligger. Derfor anbefales det altid at benytte det senest tilgængelige data og for så vidt muligt, ikke at gemme filer og lave tidsserier på basis af gamle filer.

------------------------------------------------------

Filerne indeholder data opgjort på opdateringsdatoen, samt data pr. uge tilbage til 17. december 2021. Denne dato er valgt da omikron-varianten i denne periode blev den dominerende covid-19-variant i det danske samfund.
Bemærk at når der refereres til "smittede" inkluderes der kun til bekræftede covid-19-tilfælde fra og med denne dato. Når der refereres til "3. stik" inkluderes der også vaccinationer fra før denne dato - dog tælles vaccinationer kun med fra 14 dage efter vaccinationsdatoen, for at give tid til at vaccinationen kan tage effekt.
Disse opgørelsesmetoder er anderledes en dem anvendt på SSIs øvrige dashboards, og der kan derfor forekomme små afvigelser fra tallene på disse.

------------------------------------------------------

Data er opdelt i kommune, aldersgruppe og smitte-/vaccinationsstatus:
 - Kommune: Nuværende bopælskommune. "Alle kommuner" er inkluderet som separat værdi.
 - Aldersgruppe: Nuværende alder, opdelt i grupperne 0-2 år, 3-5 år, 6-11 år, 12-15 år, 16-19 år, 20-39 år, 40-64 år, 65-79 år og 80+ år. "Alle aldersgrupper" er inkluderet som separat værdi.
 - Smitte-/vaccinationsstatus: Personer er her indelt i fire kategorier efter deres deres smittehistorik fra og med 17. december 2021 og deres vaccinationsstatus. "Smittede" er personer med smitte i denne periode, men som ikke har modtaget 3. vaccinestik. "3. stik" er personer uden smitte i perioden, men som har modtaget 3. vaccinestik. "Smittede og 3. stik" er personer med smitte i perioden og med 3. stik. "Smittede og/eller 3. stik" er personer der har været smittet i perioden og/eller har modtaget 3. vaccinestik.

------------------------------------------------------

Nedenfor følger en oversigt over kolonner i de enkelte filer, med uddybende kommentarer angivet i parantes.

Smitte_og_vaccine_noegletal:
 - Dato (opgørelsesdato for denne fils data)
 - Kommune
 - Aldersgruppe
 - Smitte-/vaccinationsstatus
 - Andel af befolkningen (andel med den pågældende smitte-/vaccinationsstatus ud af den totale befolkning i den pågældende kommune/aldersgruppe)

Smitte_og_vaccine_pr_uge:
 - Uge (kalenderuge)
 - Kommune
 - Aldersgruppe
 - Smitte-/vaccinationsstatus
 - Andel af befolkningen (andel med den pågældende smitte-/vaccinationsstatus ud af den totale befolkning i den pågældende kommune/aldersgruppe)
