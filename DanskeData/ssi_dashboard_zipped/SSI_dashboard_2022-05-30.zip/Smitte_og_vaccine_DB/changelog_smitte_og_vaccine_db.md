# Ændringslog (Changelog)

**English version below the Danish version**

Alle betydelige ændringer, der har betydning for covid-19 tallene i det kommunale smittetryksdashboard bliver dokumenteret i denne fil.

Formatet er baseret på [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
og versionsnummeringen er baseret på [Semantic Versioning](https://semver.org/spec/v2.0.0.html). 

## [1.1.0] - 2022-05-18T14:00:00
### Tilføjet
- changelog fil tilføjet.

## [1.0.0] - 2022-04-07T14:00:00
### Tilføjet 
- CSV-filer og dashboardet bliver launched.

**slutning af dansk version**

**English version**

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2022-05-18T14:00:00
### Added 
- changelog file added.

## [1.0.0] - 2022-04-07T14:00:00
### Added 
- CSV files and the dashboard is launched.

**end of English version**