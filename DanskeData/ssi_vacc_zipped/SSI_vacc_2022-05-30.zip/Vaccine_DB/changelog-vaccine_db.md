# Ændringslog (Changelog)

**English version below the Danish version**

Alle betydelige ændringer, der har betydning for covid-19-vaccine-tallene i det bliver dokumenteret i denne fil.

Formatet er baseret på [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
og versionsnummeringen er baseret på [Semantic Versioning](https://semver.org/spec/v2.0.0.html). 

## [2.0.0] - 2022-05-23T14:00:00
### Tilføjet 
- Der er nu tilføjet en changelog.md fil, der indeholder beskrivelser om ændringer i opgørelsesmetoder.

## [1.0.0] - 2021-02-22T14:00:00
### Tilføjet
- Vaccinedashboardet lanceres. <https://www.ssi.dk/aktuelt/nyheder/2021/statens-serum-institut-lancerer-et-nyt-covid-19-vaccinations-dashboard>

**slutning af dansk version**

**English version**

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0] - 2022-05-23T14:00:00
### Added 
- changelog.md file added.

## [1.0.0] - 2021-02-22T14:00:00
### Tilføjet
- The vaccine dashboard launched. <https://www.ssi.dk/aktuelt/nyheder/2021/statens-serum-institut-lancerer-et-nyt-covid-19-vaccinations-dashboard>

**end of English version**