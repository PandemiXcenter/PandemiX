﻿				*******************************************************************************
				***********************************MÅLGRUPPER**********************************
				*******************************************************************************
Dette dokument beskriver indholdet af zip-filen. Variabelnavnene, som beskrives nedenfor, refererer til søjlenavne medmindre andet er beskrevet. 

Generel struktur:
Rækkerne i filerne er som udgangspunkt opdelt efter relevante parametre, eksempelvis aldersgruppering eller tidsopdeling. Filerne er komma-separerede.

Filerne bliver opdateret hver dag og i denne forbindelse kan tidsserier også ændre sig tilbage i tiden, hvis nyere data foreligger. Derfor anbefales det altid at benytte det senest tilgængelige data og for så vidt muligt, ikke at gemme filer og lave tidsserier på basis af gamle filer.
------------------------------------------------------

Fil 1: Noegletal_vacc_daekning.csv

Bopælsregion: Bopælsregion
Målgruppe: Vaccinationsmålgruppe ifht. Sundhedsstyrelsens vaccinationskalender
Ansættelsessted: Ansættelsessted, gældende for målgruppe 4
Antal førstevaccinerede: Antal påbegyndte vaccinationer for den givne målgruppe/undergruppe og region totalt
Antal færdigvaccinerede: Antal færdigvaccinerede for den givne målgruppe/undergruppe og region totalt
Population: Total befolkning, opdelt på målgruppe/undergruppe og region
Førstegangs vaccinerede dækning (%): Andel af befolkningen som er vaccineret mindst en gang, opdelt på målgruppe/undergruppe og region
Færdigvaccinerede dækning (%): Andel af befolkningen som er færdigvaccineret, opdelt på målgruppe/undergruppe og region


OBS: Gruppen andre_vaccinerede dækker over data som er blevet censureret fra andre grupper i henhold til GDPR.


------------------------------------------------------

Fil 2: Maalgrp_Vacc_daekning_Region.csv

Bopælsregion: Bopælsregion.
1.Plejehjemsbeboere, Dækning - Første vacc.:  Andel af målgruppe 1 som har påbegyndt vaccination, fordelt på region
2. Borgere > 65, praktisk hjælp og personlig pleje, Dækning - Første vacc.: Andel af målgruppe 2 som har påbegyndt vaccination, fordelt på region
3. Borgere fra årgang 1936 og derunder (85 år og ældre), Dækning - Første vacc.: Andel af målgruppe 3 som har påbegyndt vaccination, fordelt på region
4. Personale i sundhedsvæsenet og dele af socialvæsenet, Dækning - Første vacc.: Andel af målgruppe 4 som har påbegyndt vaccination, fordelt på region og arbejdssted
5. Udvalgte patienter med særligt øget risiko, Dækning - Første vacc.: Andel af målgruppe 5 som har påbegyndt vaccination, fordelt på region
6. Udvalgte pårørende til personer med særligt øget risiko, Dækning - Første vacc.: Andel af målgruppe 6 som har påbegyndt vaccination, fordelt på region
7. Personer fra årgang 1937-1941, Dækning - Første vacc.: Andel af målgruppe 7 som har påbegyndt vaccination, fordelt på region
8. Personer fra årgang 1942-1946, Dækning - Første vacc.: Andel af målgruppe 8 som har påbegyndt vaccination, fordelt på region
9. Personer fra årgang 1947-1956, Dækning - Første vacc.: Andel af målgruppe 9 som har påbegyndt vaccination, fordelt på region
10A. Personer fra årgang 1957-1961, Dækning - Første vacc.: Andel af målgruppe 10A som har påbegyndt vaccination, fordelt på region
10B. Personer fra årgang 1962-1966, Dækning - Første vacc.: Andel af målgruppe 10B som har påbegyndt vaccination, fordelt på region
99999.Resterende, Dækning - første vacc.: andel af resterende som har påbegyndt vaccination, fordelt på region
1.Plejehjemsbeboere, Dækning - Færdigvacc vacc.:  Andel af målgruppe 1 som er færdigvaccinerede, fordelt på region
2. Borgere > 65, praktisk hjælp og personlig pleje, Dækning - Færdigvacc.: Andel af målgruppe 2 som er færdigvaccinerede, fordelt på region
3. Borgere fra årgang 1936 og derunder (85 år og ældre), Dækning - Færdigvacc.: Andel af målgruppe 3 som er færdigvaccinerede, fordelt på region
4. Personale i sundhedsvæsenet og dele af socialvæsenet, Dækning - Færdigvacc.: Andel af målgruppe 4 som er færdigvaccinerede, fordelt på region og arbejdssted
5. Udvalgte patienter med særligt øget risiko, Dækning - Færdigvacc.: Andel af målgruppe 5 som er færdigvaccinerede, fordelt på region
6. Udvalgte pårørende til personer med særligt øget risiko, Dækning - Færdigvacc.: Andel af målgruppe 6 som er færdigvaccinerede, fordelt på region
7. Personer fra årgang 1937-1941, Dækning - Færdigvacc.: Andel af målgruppe 7 som er færdigvaccinerede, fordelt på region
8. Personer fra årgang 1942-1946, Dækning - Færdigvacc.: Andel af målgruppe 8 som er færdigvaccinerede, fordelt på region
9. Personer fra årgang 1947-1956, Dækning - Færdigvacc.: Andel af målgruppe 9 som er færdigvaccinerede, fordelt på region
10A. Personer fra årgang 1957-1961, Dækning - Færdigvacc.: Andel af målgruppe 10A som er færdigvaccinerede, fordelt på region
10B. Personer fra årgang 1962-1966, Dækning - Færdigvacc.: Andel af målgruppe 10B som er færdigvaccinerede, fordelt på region
99999.Resterende, Dækning - første vacc.: andel af resterende som er færdigvaccineret, fordelt på region



------------------------------------------------------

Fil 3: Vaccinerede_pr_uge_pr_maalgruppe.csv

Ugenummer: Ugenummer
Målgruppe: Målgruppe i vaccinationskalenderen
Dækning førstegangsvaccinerede (kumulativt i %): Andelen som har modtaget første vaccination, opgjort kumulativt på ugebasis, fordelt på region og målgruppe
Dækning færdigvaccinerede (kumulativt i %): Andelen som har modtaget første vaccination, opgjort kumulativt på ugebasis, fordelt på region og målgruppe

Fil 4: Autorisation.csv
Bopælsregion: Bopælsregion
Antal førstevaccinerede: Antal påbegyndt vaccinerede, fordelt på autorisation og region
Antal færdigvaccinerede: Antal færdigvaccinerede, fordelt på autorisation og region
Autorisation, gældende for personer i målgruppe 4: Autorisation, gældende for personer i målgruppe 4
Population: Antal borger i gruppen

------------------------------------------------------