Dette dokument beskriver indholdet af filen Vaccination_sogne. Variabelnavnene, som beskrives nedenfor, refererer til søjlenavne.
Filen bliver opdateret hver onsdag, med data fra tirsdag. 

Datakilder og opgørelsesfrekvenser:
•	CPR-registeret: Opgjort tirsdag
•	Målgruppedata (TcDK): Opgjort mandag
•	Det Danske Vaccinationsregister: Opgjort tirsdag
•	Bookingdata: Opdateres mandag aften


Generel beskrivelse:
Population primær vaccination:I opgørelsen indgår personer, der er inviteret til vaccination mod COVID-19 for mindst 7 dage siden. Det vil sige, at personer, der er inviteret inden for de sidste 7 dage ikke indgår. 
Population revaccination:I opgørelsen indgår personer, der er inviteret til revaccination mod COVID-19 for mindst 7 dage siden. Det vil sige, at personer, der er inviteret inden for de sidste 7 dage ikke indgår.

I opgørelsen tages der udgangspunkt i de forskellige trin i vaccinations-/revaccinationsforløbet. 
Opgørelsen er lavet, så personer kun kan optræde på ét trin i henholdsvis det primære vaccinationsforløb og revaccinationsforløbet. Der indplaceres på det højeste trin i forløbet, hvor vaccination er et højere trin
end inviteret til og booket tid til vaccination. Derfor summer andelene på de fire trin for primære vaccinationsforløb og de tre trin i revaccinatinsforløbet hver især til 100 pct. 
Personer, der i forbindelse med tilvalgsordningen har fået en primær vaccination med vaccinen fra Johnson & Johnson vil indgå under færdigvaccinerede.

Antal inviterede er for begge forløb vist i antal personer, da det er personer på disse trin, som kommunerne retter en særlig indsats overfor. 

Vær opmærksom på, at opgørelsen over det primære vaccinationsforløb afviger fra opgørelserne på det interaktive dashboard og andre opgørelser for vaccinationstilslutning på SSIs hjemmeside, 
hvor personer kan indgå i både gruppen for påbegyndt vaccination og færdigvaccineret.


Diskretionering:
Opgørelsen vil blive diskretioneret, hvis befolkningen i sognet er færre end 20 personer. I de fleste tilfælde vil personerne fortsat indgå i opgørelsen af kommunen, 
men uden at være tilknyttet et sogn. Er der under 20 personer, der ikke kan tilknyttes et sogn vil data dog blive fjernet fra opgørelsen. 
Hvis der er mindre end 10 personer i gruppen af antal inviterede, der ikke har booket eller er vaccineret, vil det fremgå som <10 og andelene vil være diskretioneret.


------------------------------------------------------

Beskrivelse af variable:

Bo_kom_today:			Bopælskommune på opgørelsestidspunktet.
Sognekode:			Koden på sognet.
Sogn: 				Bopælssogn på opgørelsestidspunktet. Enkelte sogne fordeler sig geografisk over flere kommuner og vil derfor fremgå flere gange.
				Personer, der ikke har en adresse, kan ikke placeres i et sogn. De vil fremgå under kommunen, men uden et sogn (se også under diskretionering).

Variable relateret til det primærevaccinationsforløb:
Inviterede_i_sognet:            Det samlede antal personer, som opgørelsen tager udgangspunkt i.
Antal_inviteret_ikke_booket:    Antal personer, som er inviteret, men endnu ikke har booket tid, er påbegyndt eller har færdiggjort vaccination.
Andel_inviteret_ikke_booket:    Andel personer, som er inviteret, men endnu ikke har booket tid, er påbegyndt eller har færdiggjort vaccination.
Andel_booket:                   Andel personer, som har booket tid, men som ikke er påbegyndt eller har færdiggjort vaccination.
Andel_påbegyndt:                Andel personer, som er påbegyndt vaccination, men ikke har færdiggjort vaccination.
Andel_færdigvaccineret:         Andel personer, som har færdiggjort vaccination.

Variable relateret til revaccinationsforløb:
Invi_i_sognet_revac:		Det samlede antal personer, som er inviteret til revaccination i det givne sogn.
Antal_invi_ikke_booket_revac: 	Antal personer, som er inviteret til revaccination, men endnu ikke har booket tid eller er blevet revaccineret.
Andel_invi_ikke_booket_revac:	Andel personer, som er inviteret til revaccination, men endnu ikke har booket tid eller er blevet revaccineret.
Andel_booket_revac:		Andel personer, som har booket tid til revaccination, men som ikke er blevet revaccineret.
Andel_revaccineret:		Andel personer, som er blevet revaccineret. 
-----------------------------------------------------