Dette dokument beskriver indholdet af zip-filen, som indeholder data om det danske covid-19-vaccinationsprogram. Dette data stemmer overens med, hvad der vises på SSIs vaccinations-dashboards, men der er dog også data i zip-filen, som ikke bliver præsenteret på dashboards.
Zippen udgives kl. 14 i hverdagene. Filer med daglige tidsserier kan ændre sig tilbage i tiden, hvis nyere data foreligger. Derfor anbefales det altid at benytte det senest tilgængelige data og for så vidt muligt, ikke at gemme filer og lave tidsserier på basis af gammelt data.

Opdateret: 2023-02-10

Filerne indeholder vaccinationsdata for forskellige undergrupper af borgere. Borgere underopdeles efter forskellige kombinationer af følgende:
 - Regionskode
 - Region
 - Kommune
 - Aldersgruppe (se note om aldersgrupper*)
 - Køn (M = mænd, K = kvinder)
Data opgøres enten for hele vaccinationsprogrammet, eller pr. dag eller uge.

Filer indeholder som udgangspunkt følgende data:
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Antal borgere
 - Dækning 1. stik (%)
 - Dækning 2. stik (%)
 - Dækning 3. stik (%)
 - Dækning 4. stik (%)

Antal stik angiver antal borgere i den givne undergruppe, der har modtaget et vaccinestik.
Dækning udregnes som antal stik divideret med antal borgere.

Fra d. 12. oktober 2022 overgås til følgende opgørelsesmetode/navngivning
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. september 2022
- Antal borgere

Filer opgjort pr. dag eller uge indeholder følgende data:
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Antal borgere
 - Samlet antal 1. stik
 - Samlet antal 2. stik
 - Samlet antal 3. stik
 - Samlet antal 4. stik
 - Samlet dækning 1. stik (%)
 - Samlet dækning 2. stik (%)
 - Samlet dækning 3. stik (%)
 - Samlet dækning 4. stik (%)
Her angiver antal stik antallet af borgere i den givne undergruppe, der har modtaget et vaccinestik den dag eller uge. 
Samlet antal stik angiver det kumulerede antal af borgere i den givne undergruppe, der har modtaget et vaccinestik op til og med den dag eller uge.
Samlet dækning udregnes som samlet antal stik divideret med antal borgere i hele Danmarks befolkningen.

Fra d. 12. oktober 2022 overgås til følgende opgørelsesmetode/navngivning
- Samlet antal primærvaccinerede
- Samlet antal boostervaccinerede
- Samlet antal boostervaccinerede siden d. 15. sep
- Samlet dækning primærvaccinerede (%) 
- Samlet dækning boostervaccinerede (%)  
- Samlet dækning boostervaccinerede siden d. 15. sep (%) 

"Primærvaccinerede" har modtaget 2 stik.
"Boostervaccinerede" har modtaget 3 eller flere stik.

Samlet betyder at data er kummulerede pr. dato eller uge.

Data pr. stik vil stadig blive publiceret i en periode. 

Små afvigelser fra systemet beskrevet ovenfor forekommer i filerne med nøgletal og vaccinetyper.

------------------------------------------------------

* NOTE OM ALDERSGRUPPER
Fra d. 12. oktober 2022 tilføjes filer med følgende aldersgrupper: 
0-4, 5-11, 12-15, 16-19, 20-39, 40-49, 50-64, 65-84, 85+
Disse nye aldersgrupper vil blive vist på dashboards (dog ikke 0-4 år). 

------------------------------------------------------

Generel struktur:
_______________________________________________________________________________
Rækkerne i filerne er som udgangspunkt opdelt efter relevante 
parametre, eksempelvis aldersgruppering eller tidsopdeling. 
Der opdeles generelt efter variablen i første søjle. 
Enkelte tabeller kan have rækker, som afviger fra dette mønster. 
I disse tabeller specificeres dette i "Noter" under tabellens 
variabelbeskrivelse. De enkelte kolonner er semikolonseparerede.

Definitioner: 
_______________________________________________________________________________
Definitioner der benyttes i dette og datafilerne er beskrevet på SSI's COVID-19-
side under Datakilder og definitioner. 
https://covid19.ssi.dk/datakilder-og-definitioner
Den 8. december 2021 ændredes definitionen af "seneste 7 dage". 

Opdateringer:
_______________________________________________________________________________
Filerne bliver opdateret hver dag. I den forbindelse kan tidsserier også 
ændre sig tilbage i tiden, hvis nyere data foreligger. Derfor anbefales det 
altid at benytte det senest tilgængelige data og så vidt muligt, 
ikke at gemme filer og lave tidsserier på basis af gamle filer.

------------------------------------------------------

Nedenfor følger en oversigt over kolonner i de enkelte filer, med uddybende kommentarer angivet i parantes.

Vaccine_noegletal_kommune:
 - Dato: Vaccinationsdato
 - Kommunekode af bopælskommune
 - Kommune: Bopælskommunenavn, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
 - Køn (M = mænd, K = kvinder)
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Antal 1. stik siden i går (ændringer i det samlede antal vaccinerede siden sidste opdatering)
 - Antal 2. stik siden i går
 - Antal 3. stik siden i går 
 - Antal 4. stik siden i går 
 - Antal borgere: : Antal borgere, der lige nu bor i den pågældende kommune
 - Dækning 1. stik (%)
 - Dækning 2. stik (%)
 - Dækning 3. stik (%)
 - Dækning 4. stik (%)

Vaccine_noegletal_region:
 - Dato: Vaccinationsdato
 - Regionskode af bopælsregion
 - Region: Bopælsregion, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
 - Køn (M = mænd, K = kvinder)
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Antal 1. stik siden i går (ændringer i det samlede antal vaccinerede siden sidste opdatering)
 - Antal 2. stik siden i går
 - Antal 3. stik siden i går 
 - Antal 4. stik siden i går
 - Antal borgere: : Antal borgere, der lige nu bor i den pågældende region
 - Dækning 1. stik (%)
 - Dækning 2. stik (%)
 - Dækning 3. stik (%)
 - Dækning 4. stik (%)

Vaccine_dato:
 - Dato: Vaccinationsdato
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Antal borgere: Hele Danmarks befolkning
 - Samlet antal 1. stik
 - Samlet antal 2. stik
 - Samlet antal 3. stik
 - Samlet antal 4. stik
 - Samlet dækning 1. stik (%)
 - Samlet dækning 2. stik (%)
 - Samlet dækning 3. stik (%)
 - Samlet dækning 4. stik (%)

Vaccine_dato_kommune:
 - Dato: Vaccinationsdato
 - Kommunekode af bopælskommune
 - Kommune: Bopælskommunenavn
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Antal borgere: Antal borgere, der lige nu bor i den pågældende kommune
 - Samlet antal 1. stik
 - Samlet antal 2. stik
 - Samlet antal 3. stik
 - Samlet antal 4. stik
 - Samlet dækning 1. stik (%)
 - Samlet dækning 2. stik (%)
 - Samlet dækning 3. stik (%)
 - Samlet dækning 4. stik (%)

Vaccine_dato_region:
 - Dato: Vaccinationsdato
 - Regionskode af bopælsregion
 - Region: Bopælsregion
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Antal borgere: Antal borgere, der lige nu bor i den pågældende region
 - Samlet antal 1. stik
 - Samlet antal 2. stik
 - Samlet antal 3. stik
 - Samlet antal 4. stik
 - Samlet dækning 1. stik (%)
 - Samlet dækning 2. stik (%)
 - Samlet dækning 3. stik (%)
 - Samlet dækning 4. stik (%)
 
Vaccine_kommune:
 - Kommunekode af bopælskommune
 - Kommune: Bopælskommunenavn
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Antal borgere: Antal borgere, der lige nu bor i den pågældende kommune
 - Dækning 1. stik (%)
 - Dækning 2. stik (%)
 - Dækning 3. stik (%)
 - Dækning 4. stik (%)

Vaccine_region:
 - Regionskode af bopælsregion
 - Region: Bopælsregion
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Antal borgere: Antal borgere, der lige nu bor i den pågældende region
 - Dækning 1. stik (%)
 - Dækning 2. stik (%)
 - Dækning 3. stik (%)
 - Dækning 4. stik (%)

Vaccine_type_region:
 - Vaccinenavn: Angiver den specifikke type covid-19-vaccine modtaget ved vaccination
 - Regionskode af bopælsregion
 - Region: Bopælsregionnavn
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik

Vaccine_dato_type_region:
 - Dato: Vaccinationsdato	
 - Vaccinetype: Angiver den specifikke type covid-19-vaccine modtaget ved vaccination
 - Regionskode af bopælsregion
 - Region: Bopælsregion
 - Antal 1. stik
 - Antal 2. stik
 - Antal 3. stik
 - Antal 4. stik
 - Samlet antal 1. stik
 - Samlet antal 2. stik
 - Samlet antal 3. stik
 - Samlet antal 4. stik

Vaccine_noegletal_region_forloeb_booster
- Dato: Vaccinationsdato
- Regionskode af bopælsregion
- Region: Bopælsregion, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Køn (M = mænd, K = kvinder)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. sep
- Antal primærvaccinerede siden sidste opdatering
- Antal boostervaccinerede siden i går
- Antal boostervaccinerede siden sidste opdatering - kun vacc. givet fra d. 15. sep
- Antal borgere: Antal borgere i dag
- Dækning primærvaccinerede (%)
- Dækning boostervaccinerede (%)
- Dækning boostervaccinerede siden d. 15. sep (%)

Vaccine_noegletal_kommune_forloeb_booster
- Dato: Vaccinationsdato
- Kommunekode af bopælskommune
- Kommune: Bopælskommunenavn, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Køn (M = mænd, K = kvinder)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. sep
- Antal primærvaccinerede siden sidste opdatering
- Antal boostervaccinerede siden i går
- Antal boostervaccinerede siden sidste opdatering - kun vacc. givet fra d. 15. sep
- Antal borgere: Antal borgere i dag
- Dækning primærvaccinerede (%)
- Dækning boostervaccinerede (%)
- Dækning boostervaccinerede siden d. 15. sep (%)

Vaccine_alder_koen_forloeb_booster
- Aldersgruppe (se note om aldersgrupper*)
- Køn (M = mænd, K = kvinder)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. sep
- Antal borgere: Antal borgere i aldersgruppen i dag (ved dataudgivelsestidspunktet).
- Dækning primærvaccinerede (%)
- Dækning boostervaccinerede (%)
- Dækning boostervaccinerede siden d. 15. sep (%)

Vaccine_dato_booster
- Dato: Vaccinationsdato
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden 15. sep
- Antal borgere: Hele Danmarks befolkning
- Samlet antal primærvaccinerede
- Samlet antal boostervaccinerede
- Samlet antal boostervaccinerede siden 15. sep
- Samlet dækning primærvaccinerede (%)
- Samlet dækning boostervaccinerede (%)
- Samlet dækning boostervaccinerede siden 15. sep (%)

Vaccine_dato_kommune_forloeb_booster
- Dato: Vaccinationsdato
- Kommunekode af bopælskommune
- Kommune: Bopælskommunenavn, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden 15. sep
- Antal borgere: Antal borgere i den kommune i dag
- Samlet antal primærvaccinerede
- Samlet antal boostervaccinerede
- Samlet antal boostervaccinerede siden 15. sep
- Samlet dækning primærvaccinerede (%)
- Samlet dækning boostervaccinerede (%)
- Samlet dækning boostervaccinerede siden 15. sep (%)

Vaccine_dato_region_forloeb_booster
- Dato: Vaccinationsdato
- Regionskode af bopælsregion
- Region: Bopælsregion, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden 15. sep
- Antal borgere: Antal borgere i dag
- Samlet antal primærvaccinerede
- Samlet antal boostervaccinerede
- Samlet antal boostervaccinerede siden 15. sep
- Samlet dækning primærvaccinerede (%)
- Samlet dækning boostervaccinerede (%)
- Samlet dækning boostervaccinerede siden 15. sep (%)

Vaccine_dato_region_alder_forloeb_booster
- Dato: Vaccinationsdato
- Aldersgruppe (se note om aldersgrupper*)
- Regionskode af bopælsregion
- Region: Bopælsregion, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden 15. sep
- Antal borgere: Antal borgere i dag
- Samlet antal primærvaccinerede
- Samlet antal boostervaccinerede
- Samlet antal boostervaccinerede siden 15. sep
- Samlet dækning primærvaccinerede (%)
- Samlet dækning boostervaccinerede (%)
- Samlet dækning boostervaccinerede siden 15. sep (%)

Vaccine_kommune_forloeb_booster
- Kommunekode af bopælskommune
- Kommune: Bopælskommunenavn, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. sep
- Antal borgere: Antal borgere i dag
- Dækning primærvaccinerede (%)
- Dækning boostervaccinerede (%)
- Dækning boostervaccinerede siden d. 15. sep (%)

Vaccine_region_forloeb_booster
- Regionskode af bopælsregion
- Region: Bopælsregion, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. sep
- Antal borgere: Antal borgere i dag
- Dækning primærvaccinerede (%)
- Dækning boostervaccinerede (%)
- Dækning boostervaccinerede siden d. 15. sep (%)

Vaccine_region_alder_koen_forloeb_booster
- Regionskode af bopælsregion
- Region: Bopælsregion, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Aldersgruppe (se note om aldersgrupper*)
- Køn (M = mænd, K = kvinder)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. sep
- Antal borgere: Antal borgere i aldersgruppen i dag (ved dataudgivelsestidspunktet).
- Dækning primærvaccinerede (%)
- Dækning boostervaccinerede (%)
- Dækning boostervaccinerede siden d. 15. sep (%)

Vaccine_type_region_forloeb_booster
- Vaccinenavn (angiver den specifikke type covid-19-vaccine modtaget ved vaccination)
- Regionskode af bopælsregion
- Region: Bopælsregion, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. sep

Vaccine_uge_alder_forloeb_booster
- Uge
- Aldersgruppe (se note om aldersgrupper*)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. sep
- Antal borgere: Antal borgere i aldersgruppen i dag (ved dataudgivelsestidspunktet).
- Samlet antal primærvaccinerede
- Samlet antal boostervaccinerede
- Samlet antal boostervaccinerede siden d. 15. sep
- Samlet dækning primærvaccinerede (%)
- Samlet dækning boostervaccinerede (%)
- Samlet dækning boostervaccinerede siden d. 15. sep (%)

Vaccine_dato_type_region_forloeb_booster
- Dato: Vaccinationsdato
- Vaccinenavn (angiver den specifikke type covid-19-vaccine modtaget ved vaccination)
- Regionskode af bopælsregion
- Region: Bopælsregion, hvor de vaccinerede bor nu (uanset hvor de boede på vaccinationstidspunktet)
- Antal primærvaccinerede
- Antal boostervaccinerede
- Antal boostervaccinerede siden d. 15. sep
- Samlet antal primærvaccinerede
- Samlet antal boostervaccinerede
- Samlet antal boostervaccinerede siden d. 15. sep