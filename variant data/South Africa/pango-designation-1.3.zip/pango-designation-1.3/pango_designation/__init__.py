__version__ = "1.3"
_program = "pango_designation"
