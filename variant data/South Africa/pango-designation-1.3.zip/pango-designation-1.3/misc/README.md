Location of miscellaneous files useful to the Pango Designation process
